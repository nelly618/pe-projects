
# Hello! This is a README

It is written in "markdown." Do you know what that is? If not, ask. : )

# Heading 1

Regular paragraph

## Heading 2

A paragraph with...

* A list of

* Things like this

## What is the point?

You READ it. "Read Me!"

When you first get to a project, this is the "how to" for getting set up and helpful instruction on how to parse the file structure and get thigns up and running.

## Requirements

1. MAMP

2. A browser

3. A text editor

## HOW TO

READ the index.php file from top to bottom. Every time something is 'included' - go look at that file. Keep going until you've read the whole document. Look at the folder structure. You should understand most of it. Write down any questions you have and ask them. : )

## Further info

You can download a "markdown" viewer with Sublime. You can also read about markdown on [the website](https://daringfireball.net/projects/markdown/).
