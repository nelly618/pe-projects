<?php

$database = [ // an associative array (Array of key:value pairs)
	[
		"heading" => "Article or product",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "https://peprojects.dev/images/landscape.jpg",
	],
	[
		"heading" => "Destination or option",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "https://peprojects.dev/images/landscape.jpg",
	],
	[
		"heading" => "Story or something",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "https://peprojects.dev/images/landscape.jpg",
	],
	[
		"heading" => "Banana tandori",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "https://peprojects.dev/images/landscape.jpg",
	],
	[
		"heading" => "Bar B Q",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "https://peprojects.dev/images/landscape.jpg",
	],
	[
		"heading" => "Marsala",
		"description" => "Here's a little info to help you understand if this is a thing you want to know about.",
		"thumbnail" => "https://peprojects.dev/images/landscape.jpg",
	],
];
