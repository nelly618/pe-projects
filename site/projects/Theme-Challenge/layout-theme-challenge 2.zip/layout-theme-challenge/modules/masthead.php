
<mast-head>

	<nav class='site-menu'>
		<a class='logo' href='#'>
			<img src="images/logo.svg" alt="">
			<!-- or you could actually use the SVG -->
		</a>

		<a href='#'>
			<span>Some page</span>
		</a>

		<a href='#'>
			<span>"Masthead"</span>
		</a>
	</nav>


	<nav class='user-menu'>
		<a href='#'>
			<span>Sign-in</span>
		</a>
	</nav>

</mast-head>
