
<graphic-diptych>

	<picture>
		<img src='https://peprojects.dev/images/square.jpg' alt='$todo'>
	</picture>

	<text-content>
		<h1 class='intro-voice'>Hello! This is a 'diptych'</h1>

		<p class='calm-voice'>You can call it whatever you want. It's a module that has an image and some supporting text. On the smaller screen it works nicely to stack. On a larger screen, it fits side by side.</p>
	</text-content>

</graphic-diptych>
