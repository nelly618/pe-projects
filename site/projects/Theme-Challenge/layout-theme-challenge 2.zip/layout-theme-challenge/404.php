
<?php include('header.php'); ?>



<section class='not-found'>
<inner-column>

	<call-to-action>

		<h2 class='attention-voice'>Oh no! The page you are looking for... does not exist!</h2>

		<p class='calm-voice'>Here are some reasons... and things you can do.</p>

		<a href='#'>
			<span>Here's an action!</span>
		</a>

	</call-to-action>

</inner-column>
</section>



<?php include('footer.php'); ?>
