
<call-to-action>

	<h2 class='attention-voice'>This module is a "call to action"</h2>

	<p class='calm-voice'>These aren't names you should memorize. We're just making them up. Sometimes things get called something so many times, that it sticks. This is a pretty common pattern</p>

	<a href='#'>
		<span>Here's the action!</span>
	</a>

</call-to-action>
