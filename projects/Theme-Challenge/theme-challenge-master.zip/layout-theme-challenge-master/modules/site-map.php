
<site-map>

	<nav class='site-menu'>
		<a class='logo' href='#'>
			<?php include("./icons/circle.php"); ?>
		</a>
		<a href='./'>Home</a>
		<a href='404.php'>404 error</a>
	</nav>

	<nav class='user-menu'>
		<h3>Account Menu</h3>

		<a href='#'>Sign-in</a>
	</nav>

	<nav class='legal-menu'>
		<h3>Legal Menu</h3>

		<a href='#'>Legal thing a</a>
		<a href='#'>Legal thing b</a>
	</nav>

	<nav class='social-menu'>
		<h3>Social Menu</h3>

		<a href='#'>social thing a</a>
		<a href='#'>social thing b</a>
		<a href='#'>social thing c</a>
		<a href='#'>social thing d</a>
	</nav>

</site-map>
