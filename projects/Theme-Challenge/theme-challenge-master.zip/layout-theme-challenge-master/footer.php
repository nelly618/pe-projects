
			<!-- STUFF -->
		</main>


		<footer class='site-footer'>
		<inner-column>

			<!-- no headers in footers allowed? -->
			<div class='what-to-call-it-then'>
				<h2 class='attention-voice'>This is the site footer and it has a "site-map" module in it.</h2>

				<p>Pretty standard type of thing, right?</p>
			</div>

			<?php include('modules/site-map.php'); ?>

		</inner-column>
		</footer>

	</body>
</html>