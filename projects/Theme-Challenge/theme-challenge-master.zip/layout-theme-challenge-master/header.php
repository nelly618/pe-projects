<!doctype html>

<html lang='en'>
	<?php include('head.php'); ?>

	<body>
		<header class='site-header'>
		<inner-column>

			<?php include('modules/masthead.php'); ?>

		</inner-column>
		</header>


		<main class='page-content'>
			<!-- STUFF -->
