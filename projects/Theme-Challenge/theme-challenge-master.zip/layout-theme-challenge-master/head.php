<head>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1'>

	<title>Super theme challenge</title>
	<meta name='description' content='[[insert description]]'>
	<meta property='og:image' content='images/default.png'>

	<link rel='stylesheet' href='css/style.css'>
</head>