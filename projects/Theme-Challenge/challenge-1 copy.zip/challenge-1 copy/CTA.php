<?php 

$moduleOne = [
	"h1" => "This is a Call-to-Action",
	"p" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ex sit, enim officia dicta, consequuntur obcaecati tempora! Hic voluptatum esse, minus iure dolorum nisi pariatur laboriosam quis, aspernatur sed error, vitae?",
	"button" => "Let's Go!"
];

$moduleTwo = [
	"h1" => "This is a Call-to-Action",
	"p" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ex sit, enim officia dicta, consequuntur obcaecati tempora! Hic voluptatum esse, minus iure dolorum nisi pariatur laboriosam quis, aspernatur sed error, vitae?",
	"button" => "Let's Go!"
];

$CTA = $moduleOne;

	echo "<module><h1>" . 
		$CTA["h1"] . " 
		</h1><p>" . 
		$CTA["p"] . "
		</p><button>" . 
		$CTA["button"] . "
		</button></module>";















?>






